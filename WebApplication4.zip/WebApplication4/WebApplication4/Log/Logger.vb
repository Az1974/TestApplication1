﻿Imports System.IO

Public Class Logger

  Private _LogFilePath As String = String.Empty

  Public Sub New(ByVal logFilePath As String)
    _LogFilePath = logFilePath
  End Sub

  ''' <summary>
  ''' writes message to log file
  ''' </summary>
  Public Sub WriteToLog(logEntry As String)

    If String.IsNullOrEmpty(_LogFilePath) Then
      Exit Sub
    End If

    Const LogFileName As String = "Log.txt"

    Try

      Using streamWriter = New StreamWriter(Path.Combine(_LogFilePath, LogFileName), append:=True)
        streamWriter.WriteLine(Date.Now.ToString("yyyy-MM-dd HH:mm:ss:fff") & " " & logEntry)
        streamWriter.Flush()
        streamWriter.Close()
      End Using

    Catch ex As Exception
      Debug.Print(String.Format("The following error occurred writing to log: {0} {1} {2} ", vbCrLf & ex.Message, If(ex.InnerException IsNot Nothing, ex.InnerException.Message, String.Empty), vbCrLf & ex.StackTrace))
    End Try

  End Sub
End Class
