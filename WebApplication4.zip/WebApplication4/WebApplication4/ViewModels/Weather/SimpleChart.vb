﻿Imports WebApplication4.ViewModels

Namespace Models.Chart
  Public Class SimpleChart
    Public Class ChartTotals
      Public Property MainTotals As New List(Of Temperature)
    End Class

    Public Class Temperature
      Public Property PeriodEndDate As Date = Date.Today
      Public Property MaxTemperatureC As Decimal

    End Class

    Public Shared Sub GetSimpleChart(ByVal chartTotals As ChartTotals, ByVal startDate As Date, ByVal chartData As ChartData, ByVal model As WeatherViewModel)

      Dim chartType As SeriesType = SeriesType.Bar

      Dim titleMainSeries As String = String.Empty

      titleMainSeries = startDate.ToString("dd/MM/yyyy")

      Dim reportMainSeries As New ChartSeries()
      reportMainSeries.Name = titleMainSeries
      reportMainSeries.Type = chartType
      reportMainSeries.LegendIndex = 0

      Dim tooltipsMain As New ToolTips

      ' if there is data then create the series points
      If chartTotals.MainTotals.Count > 0 Then

        Dim currPoint As Double = 0
        Dim currRefPoint As Double = 0
        Dim currTargetPoint As Double = 0
        Dim period As Integer = 0

        For lngIndex As Integer = 0 To chartTotals.MainTotals.Count - 1

          currPoint = chartTotals.MainTotals(lngIndex).MaxTemperatureC

          reportMainSeries.Values.Add(currPoint)

          chartData.Labels.Add(Format(chartTotals.MainTotals(lngIndex).PeriodEndDate, "dd/MM/yyyy") & " (" & model.LocationName & ") (" & model.LocationRegion & ")")
          tooltipsMain.Labels.Add(chartTotals.MainTotals(lngIndex).PeriodEndDate.ToString("dd/MM/yyyy") & " (" & model.LocationName & ") (" & model.LocationRegion & ")")
        Next
      End If

      ' add the tooltips and series to chart data
      chartData.ToolTips.Add(tooltipsMain)
      chartData.Series.Add(reportMainSeries)

    End Sub

  End Class

End Namespace
