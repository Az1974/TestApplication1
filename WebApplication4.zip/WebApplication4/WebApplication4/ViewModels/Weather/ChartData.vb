﻿Namespace Models.Chart

  Public Class ChartData

    Public Property Labels As IList(Of String) = New List(Of String)
    Public Property ToolTips As IList(Of ToolTips) = New List(Of ToolTips)

    Public Property Series As IList(Of ChartSeries) = New List(Of ChartSeries)

    Public Property Units As String = String.Empty

    Public Property UnitsXAxis As String

    Public Property TooltipPrefix As String = String.Empty

    Public Property TooltipSuffix As String = String.Empty

    Public Property TooltipsPrecision As Integer = 0  ' number of decimal places precision for chart tooltip (applied to y value when hover over point)

    Public Property Stacked As Boolean = False  ' this only applies to bars
    Public Property ShowToolTips As Boolean = True
    Public Property SeriesColours As IList(Of SeriesColour) = Nothing
    Public Property ShowGridLinesXAxis As Boolean = True
    Public Property AutoSkipXLabels As Boolean = True
    Public Property ShowLegend As Boolean = True
    Public Property MaxRotation As Integer = 90
    Public Property LabelOffset As Integer = 0

    Public Property maxTicksLimitX As Integer = 0

  End Class

  Public Class ChartSeries
    Public Property Name As String
    Public Property Type As SeriesType
    Public Property LegendIndex As Integer

    Public Property LineSmoothing As Boolean = True
    Public Property ShowMarkers As Boolean = True
    Public Property Visible As Boolean = True

    Public Property Values As IList(Of Double?) = New List(Of Double?)
  End Class

  Public Class ToolTips
    Public Property Labels As IList(Of String) = New List(Of String)
  End Class

  Public Enum SeriesType
    Bar
    Line
    Area
  End Enum

  Public Class SeriesColour
    Public Property R As Integer
    Public Property G As Integer
    Public Property B As Integer
  End Class

  Public Class XY
    Public Property x As Double = 0
    Public Property y As Double = 0
    Public Property Label As String = String.Empty
  End Class

End Namespace