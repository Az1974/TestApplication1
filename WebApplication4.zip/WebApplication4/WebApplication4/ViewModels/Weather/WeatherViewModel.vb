﻿Imports System.ComponentModel.DataAnnotations
Imports WebApplication4.Models.Chart

Namespace ViewModels

  Public Class WeatherViewModel

    Public Property ChartData As ChartData

    <Required()>
    <Display(Name:="Postcode or Location")>
    Public Property Postcode As String = String.Empty

    Public Property LocationName As String = String.Empty
    Public Property LocationRegion As String = String.Empty

  End Class

End Namespace
