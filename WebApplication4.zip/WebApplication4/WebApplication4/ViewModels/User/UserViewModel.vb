﻿Imports System.ComponentModel.DataAnnotations

Namespace ViewModels

  Public Class UserViewModel

    <Required()>
    <MaxLength(20, ErrorMessage:="First Name cannot exceed 20 characters")>
    <Display(Name:="First Name")>
    Public Property FirstName As String = String.Empty

    <Required()>
    <MaxLength(20, ErrorMessage:="Last Name cannot exceed 20 characters")>
    <Display(Name:="Last Name")>
    Public Property LastName As String = String.Empty

    <Required()>
    <Display(Name:="Date Of Birth")>
    <DisplayFormat(DataFormatString:="{0:dd/MM/yyyy}", ApplyFormatInEditMode:=True)>
    Public Property DateOfBirth As Date?

    Public Property Token As Guid = Guid.Empty

  End Class

End Namespace
