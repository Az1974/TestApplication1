﻿Imports Newtonsoft.Json
Imports WebApplication4.Models
Imports WebApplication4.Models.Chart
Imports WebApplication4.Models.Chart.SimpleChart
Imports WebApplication4.ViewModels

Public Class WeatherController
  Inherits System.Web.Mvc.Controller


  <HttpGet>
  Function ShowWeather() As ActionResult
    Dim model As New WeatherViewModel
    Return View(model)
  End Function

  <HttpPost>
  Function ShowWeather(ByVal model As WeatherViewModel) As ActionResult

    Dim weatherCreateModel As WeatherViewModel = Nothing

    If ModelState.IsValid Then

      Dim api As New WeatherApi()
      Dim responseJSON As String = api.SendRequest(model.Postcode)
      Dim weatherApiResponse As WeatherModel = JsonConvert.DeserializeObject(Of WeatherModel)(responseJSON)

      Dim chartData = New ChartData()

      Dim chartTotals = New ChartTotals()
      chartTotals.MainTotals = New List(Of Temperature)
      chartTotals.MainTotals.Add(New Temperature With {.MaxTemperatureC = weatherApiResponse.Current.Temp_C})

      model.LocationName = weatherApiResponse.Location.Name
      model.LocationRegion = weatherApiResponse.Location.Region

      SimpleChart.GetSimpleChart(chartTotals, Date.Today, chartData, model)
      model.ChartData = chartData

      Return View(model)
    End If

    weatherCreateModel = CreateNewWeatherModel(model)
    Return View(weatherCreateModel)

  End Function

  Private Function CreateNewWeatherModel(ByVal model As WeatherViewModel) As WeatherViewModel
    Return New WeatherViewModel With {.Postcode = model.Postcode}
  End Function

End Class
