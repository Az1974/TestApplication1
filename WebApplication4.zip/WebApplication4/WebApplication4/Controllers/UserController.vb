﻿Imports System.IO
Imports System.Net
Imports Newtonsoft.Json
Imports WebApplication4.ViewModels

Public Class UserController
  Inherits System.Web.Mvc.Controller

  <HttpGet>
  Function CreateUser() As ActionResult
    Dim model As New UserViewModel
    Return View(model)
  End Function

  <HttpGet>
  Function ViewUser(ByVal model As UserViewModel) As ActionResult
    Return View(model)
  End Function

  <HttpPost>
  Function CreateUser(ByVal model As UserViewModel) As ActionResult

    Dim userCreateModel As UserViewModel = Nothing

    If ModelState.IsValid Then
      If IsInvalidAge(model.DateOfBirth) Then
        userCreateModel = CreateNewUserModel(model)

        Const UserAgeField As String = "DateOfBirth"
        Const UserAgeValidation As String = "User must be over 18 years old"
        ModelState.AddModelError(UserAgeField, UserAgeValidation)
      Else
        Dim requestJson As String = JsonConvert.SerializeObject(model, Formatting.None, New JsonSerializerSettings With {.StringEscapeHandling = StringEscapeHandling.EscapeNonAscii})
        Dim response As String = SendRequest(requestJson)

        If Not String.IsNullOrEmpty(response) Then
          model.Token = JsonConvert.DeserializeObject(Of Guid)(response)
        End If
        Return RedirectToAction("ViewUser", model)
      End If
    End If

    userCreateModel = CreateNewUserModel(model)
    Return View(userCreateModel)

  End Function

  Private Function IsInvalidAge(ByVal dateOfBirth As Date) As Boolean

    Const MinAgeYears As Integer = 18
    Dim userDateOfBirth As Date

    If Date.TryParse(dateOfBirth.ToString, userDateOfBirth) Then

      Dim dateDifference As TimeSpan = userDateOfBirth.Subtract(Date.Today.AddYears(-MinAgeYears))
      If dateDifference.TotalDays > 0 Then
        Return True
      End If
    End If

    Return False

  End Function

  Private Function CreateNewUserModel(ByVal model As UserViewModel) As UserViewModel
    Return New UserViewModel With {.FirstName = model.FirstName, .LastName = model.LastName, .DateOfBirth = model.DateOfBirth}
  End Function

  Public Function SendRequest(ByVal data As String) As String

    Const HeaderToken As String = "Q!WERT=Y5"
    Const APIUrlKey As String = "apiURL"
    Dim apiResponse As String = String.Empty

    Try

      Dim apiUrl As String = ConfigurationManager.AppSettings.Get(APIUrlKey) ' e.g. "http://localhost:51438/api/userapi/CreateUser"

      Dim request As HttpWebRequest = DirectCast(WebRequest.Create(String.Format("{0}", apiUrl)), HttpWebRequest)
      Const apiContentTypeJSON As String = "text/json"
      Const apiRequestMethod As String = "POST"
      Const HeaderAPIKey As String = "X-API"

      request.ContentType = apiContentTypeJSON
      request.Method = apiRequestMethod
      request.KeepAlive = False
      request.Headers.Add(HeaderAPIKey, HeaderToken)

      If WebRequest.DefaultWebProxy IsNot Nothing Then
        WebRequest.DefaultWebProxy.Credentials = System.Net.CredentialCache.DefaultCredentials
      End If

      Using streamWriter = New StreamWriter(request.GetRequestStream())
        streamWriter.Write(data)
        streamWriter.Flush()
        streamWriter.Close()
      End Using

      ' Send the request and get the response.
      Dim response As WebResponse = request.GetResponse()

      Dim serverResponse = CType(response, HttpWebResponse)

      If serverResponse.StatusCode <> HttpStatusCode.OK Then
        Return String.Empty
      End If

      Using streamReader = New StreamReader(response.GetResponseStream())
        apiResponse = streamReader.ReadToEnd()
      End Using

    Catch ex As Exception
      Debug.Print(ex.Message)
    End Try

    Return apiResponse

  End Function


End Class
