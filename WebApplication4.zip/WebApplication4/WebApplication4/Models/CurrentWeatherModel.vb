﻿
Namespace Models
  Public Class WeatherModel

    Public Property Location As New LocationModel
    Public Property Current As New CurrentModel

  End Class

  Public Class LocationModel

    Public Property Name As String = String.Empty
    Public Property Region As String = String.Empty

  End Class

  Public Class CurrentModel
    Public Property Temp_C As Decimal
    Public Property Temp_f As Decimal

  End Class

End Namespace
