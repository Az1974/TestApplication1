﻿Imports System.IO
Imports System.Net

Public Class WeatherApi

  Private _logFilePath As String = String.Empty
  Private _logger As Logger = Nothing

  Public Sub New()
  End Sub

  Private Sub InitialiseParameters()

    Const LogFileConfigEntry As String = "logFile"
    Dim _logFilePath As String = String.Empty

    Dim logFileConfig As String = ConfigurationManager.AppSettings.Get(LogFileConfigEntry)
    If Not String.IsNullOrEmpty(logFileConfig) Then
      _logFilePath = logFileConfig
    End If

    _logger = New Logger(logFileConfig)

  End Sub


  Public Function SendRequest(ByVal data As String) As String

    InitialiseParameters()

    Const APIUrlKey As String = "apiKey"
    Dim apiURL As String = "http://api.weatherapi.com/v1/forecast.json?key={0}&q={1}&days=7&aqi=no&alerts=no"
    Dim apiResponse As String = String.Empty

    Try

      Dim apiKey As String = ConfigurationManager.AppSettings.Get(APIUrlKey)
      apiURL = String.Format(apiURL, apiKey, data)

      Dim request As HttpWebRequest = DirectCast(WebRequest.Create(String.Format("{0}", apiURL)), HttpWebRequest)
      Const apiContentTypeJSON As String = "text/json"
      Const apiRequestMethod As String = "POST"
      Const HeaderAPIKey As String = "X-API"

      request.ContentType = apiContentTypeJSON
      request.Method = apiRequestMethod
      request.KeepAlive = False
      request.Headers.Add(HeaderAPIKey, apiKey)


      _logger.WriteToLog(apiURL)

      ' Send the request and get the response.
      Dim response As WebResponse = request.GetResponse()

      Dim serverResponse = CType(response, HttpWebResponse)

      If serverResponse.StatusCode <> HttpStatusCode.OK Then
        Return String.Empty
      End If

      Using streamReader = New StreamReader(response.GetResponseStream())
        apiResponse = streamReader.ReadToEnd()
        _logger.WriteToLog(apiResponse)
      End Using

    Catch ex As Exception
      _logger.WriteToLog(ex.Message)
    End Try

    Return apiResponse

  End Function

End Class
