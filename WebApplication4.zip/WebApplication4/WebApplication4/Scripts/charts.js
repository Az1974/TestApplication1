﻿var ChartHelpers = ChartHelpers || {};

ChartHelpers.SimpleChart = function(chartData, canvasId) {

    var tooltipsOptions;
    if (chartData.ShowToolTips == true){
        tooltipsOptions =  {
            mode: "index",
            position: "pointer",
            intersect: true,
            itemSort: function (a, b, data) {
                var aOrder = data.datasets[a.datasetIndex].legendOrder;
                var bOrder = data.datasets[b.datasetIndex].legendOrder;
                return aOrder > bOrder;
            },
            callbacks: {
                label: function (tooltipItem, data) {
                    if (isNaN(tooltipItem.yLabel)) {
                        return getLabelTooltipDetails(tooltipItem, data, "No data");
                    } else {
                      return getLabelTooltipDetails(tooltipItem, data, getFormattedValue(tooltipItem.yLabel, chartData.TooltipsPrecision));
                    }
                }
            }
        }
    }
    else{
        tooltipsOptions =  {
            enabled: false
        }
    }


  var options = {
    type: "bar",
    options: {
      scales: {
        xAxes: [{
            ticks: {
            alwaysShowLastTick: false,
            autoSkip: chartData.AutoSkipXLabels
          },
          gridLines: {
              display: chartData.ShowGridLinesXAxis
          }
        }],
        yAxes: [{
            scaleLabel: {
                display: true,
                labelString: ""
            },
            ticks: {
                beginAtZero: true,
                callback: function (value, index, values) {
                    return addCommas(value, getYTicksPrecision(values));
                }
            },
            stacked: chartData.Stacked
        }]
      },
      legend: {
        display: chartData.ShowLegend,
        position: "bottom",
        labels: {
          filter: function (item, data) {
            return item.text != 'hidden'
          },
          itemSort: function (a, b, data) {
            var aOrder = data.datasets[a.datasetIndex].legendOrder;
            var bOrder = data.datasets[b.datasetIndex].legendOrder;
            return aOrder > bOrder;
          }
        }
      },
      tooltips: tooltipsOptions,
      responsive: true,
      maintainAspectRatio: false
    }
  };

  Chart.Tooltip.positioners['pointer'] = function (elements, eventPosition) {
    return {
      x: eventPosition.x,
      y: eventPosition.y
    };
  }

  function getLabelTooltipDetails(tooltipItem, data, postfix) {
    if (data.tooltips != null) {
      return data.tooltips[tooltipItem.datasetIndex].Labels[tooltipItem.index] + ": " + postfix;
    }
    else {
      return data.datasets[tooltipItem.datasetIndex].label + ": " + postfix;
    }
  }

  var seriesColorsDefault = [{
          borderColor: 'rgba(70, 130, 180, 0.8)',
          fillColor: 'rgba(70, 130, 180, 0.6)'
      }, {
          borderColor: 'rgba(50, 205, 50, 0.8)',
          fillColor: 'rgba(50, 205, 50, 0.6)'
      }, {
          borderColor: 'rgba(128, 0, 128, 0.8)',
          fillColor: 'rgba(128, 0, 128, 0.6)'
      }
  ]

  var seriesColors = seriesColorsDefault;

  if (chartData.SeriesColours != null) {

      var seriesColorsCustom = [];
      for (var seriesNumber = 0; seriesNumber < chartData.SeriesColours.length; seriesNumber++) {

          var R = chartData.SeriesColours[seriesNumber].R;
          var G = chartData.SeriesColours[seriesNumber].G;
          var B = chartData.SeriesColours[seriesNumber].B;

          var borderColor = 'rgba(' + R + ', ' + G + ', ' + B + ', 0.8)';
          var fillColor = 'rgba(' + R + ', ' + G + ', ' + B + ', 0.6)';

          seriesColorsCustom.push({ 'borderColor': borderColor, 'fillColor': fillColor })

      }

      seriesColors = seriesColorsCustom;
  }

  var seriesType = { bar: 0, line: 1, area: 2 };

  var tooltipPrefix = '';
  var tooltipSuffix = '';
  function getFormattedValue(yLabel,precision) {
    return tooltipPrefix + addCommas(yLabel.toFixed(precision)) + tooltipSuffix;
  }

  options.data = {};
  options.data.labels = chartData.Labels;
  options.options.scales.yAxes[0].scaleLabel.labelString = chartData.Units;

  tooltipPrefix = chartData.TooltipPrefix;
  tooltipSuffix = chartData.TooltipSuffix;

  options.data.datasets = [];
  var hasBarSeries = false;
  for (var i = 0; i < chartData.Series.length; i++) {

    var thisSeries = chartData.Series[i];
    var thisColor = seriesColors[thisSeries.LegendIndex];

    var dataset = {
        label: thisSeries.Name,
        data: thisSeries.Values,
        legendOrder: thisSeries.LegendIndex,
        borderColor: thisColor.borderColor,
        backgroundColor: thisColor.fillColor,
        borderWidth: 2
    };

    if (thisSeries.Type === seriesType.line) {
      dataset.type = 'line';
      dataset.fill = false;
      dataset.lineTension = thisSeries.LineSmoothing ? 0.4 : 0;
      dataset.pointRadius = thisSeries.ShowMarkers ? 3 : 0;
    } else if (thisSeries.Type === seriesType.area) {
        dataset.type = 'line';
        dataset.pointRadius = thisSeries.ShowMarkers ? 3 : 0;
        dataset.lineTension = thisSeries.LineSmoothing ? 0.4 : 0;
    } else {
      dataset.type = 'bar';
      hasBarSeries = true;
    }

    dataset.hidden = !thisSeries.Visible;

    options.data.datasets.push(dataset);

  }

  // add any custom tooltips
  if (chartData.ToolTips.length > 0) {
    options.data.tooltips = chartData.ToolTips;
  }

  if (!hasBarSeries) {
    // If no bar series are present, add a hidden bar series to force a category scale.            
    var hiddenDataSet = {
      type: 'bar',
      label: 'hidden'
    }
    options.data.datasets.push(hiddenDataSet);
  }
  
  var ctx = document.getElementById(canvasId).getContext("2d");
  var myChart = new Chart(ctx, options);

  console.log(chartData);
}


function addCommas(nStr, tickPrecision) {

    nStr += '';

    if (tickPrecision) {
        nStr = Number(nStr).toFixed(tickPrecision).toString();
    }

    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;
}

function getFormattedValue(label, value, precision, tooltipPrefix, tooltipSuffix) {
    return label + ", " + tooltipPrefix + addCommas(value.toFixed(precision)) + " " + tooltipSuffix;
}

/* 
    method name :   getYTicksPrecision
    description :   returns precision of 2 for low values (where max tick value is <=5), otherwise precision of 0 
*/
function getYTicksPrecision(ticks) {

    var tickPrecision = 2;

    for (var i = 0; i < ticks.length; i++) {

        var value = ticks[i];

        if (value > 5) {
            tickPrecision = 0
            return tickPrecision;
        }
    };

    return tickPrecision;
}
