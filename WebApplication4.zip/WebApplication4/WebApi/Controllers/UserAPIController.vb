﻿Imports System.IO
Imports System.Web.Http
Imports Newtonsoft.Json
Imports WebApi.Models

Public Class UserAPIController
  Inherits ApiController

  <HttpPost>
  Public Function CreateUser() As String

    Const HeaderAPIKey As String = "X-API"
    Const HeaderToken As String = "Q!WERT=Y5"

    Dim headerAPIKeyValue As String = HttpContext.Current.Request.Headers(HeaderAPIKey)
    If String.IsNullOrEmpty(headerAPIKeyValue) OrElse headerAPIKeyValue <> HeaderToken Then
      Return "error"
    End If

    Dim requestData As String = String.Empty

    Using streamReader = New StreamReader(HttpContext.Current.Request.InputStream)
      requestData = streamReader.ReadToEnd()
    End Using

    Dim user As User = JsonConvert.DeserializeObject(Of User)(requestData)
    Dim userCreated As User = CreateUserInDatabase(user)

    Return userCreated.Token.ToString
  End Function

  ' this would add the user to the database and then return a success token
  Private Function CreateUserInDatabase(ByVal user As User) As User

    ' #TODO
    ' Dim userDAO As New UserDAO
    ' UserDAO.AddUser()

    user.Token = Guid.NewGuid
    Return user
  End Function

End Class
