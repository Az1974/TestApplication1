﻿Imports System.Data.SqlClient

Public Class UserDAO

  Public Sub AddUser(ByVal connectionString As String)

    Dim connection As SqlConnection = Nothing

    Try

      Dim sqlquery As String = "INSERT into USER"

      connection = New SqlConnection(connectionString)

      Dim command As SqlCommand = New SqlCommand(sqlquery, connection)
      command.Connection.Open()

      Dim reader As IDataReader = command.ExecuteReader()
      command.Connection.Close()

    Catch ex As Exception
      Debug.Print(ex.Message)
    Finally
      connection.Close()
    End Try

  End Sub

End Class
