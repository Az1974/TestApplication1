﻿
Namespace Models

  Public Class User
    Public Property FirstName As String = String.Empty
    Public Property LastName As String = String.Empty
    Public Property DateOfBirth As Date?
    Public Property Token As Guid = Guid.Empty

  End Class

End Namespace
