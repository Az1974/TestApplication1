﻿Imports System.IO

Public Class Logger

  ''' <summary>
  ''' writes message to log file
  ''' </summary>
  Public Sub WriteToLog(ByVal logFile As String, logEntry As String)

    Const LogFileName As String = "Log.txt"

    Try

      Using streamWriter = New StreamWriter(Path.Combine(logFile, LogFileName), append:=True)
        streamWriter.WriteLine(Date.Now.ToString("yyyy-MM-dd HH:mm:ss:fff") & " " & logEntry)
        streamWriter.Flush()
        streamWriter.Close()
      End Using

    Catch ex As Exception
      Debug.Print(String.Format("The following error occurred writing to log: {0} {1} {2} ", vbCrLf & ex.Message, If(ex.InnerException IsNot Nothing, ex.InnerException.Message, String.Empty), vbCrLf & ex.StackTrace))
    End Try

  End Sub
End Class
