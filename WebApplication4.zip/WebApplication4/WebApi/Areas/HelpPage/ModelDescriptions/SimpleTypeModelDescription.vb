Namespace Areas.HelpPage.ModelDescriptions
    Public Class SimpleTypeModelDescription
        Inherits ModelDescription
    End Class
End Namespace